int main()
{
    int a, b, c, d;

    d = 10;
    if (c > d) {
        a = 3;
        b = 2;
    } else {
        a = 2;
        b = 3;
    }

    c = a + b;
}

